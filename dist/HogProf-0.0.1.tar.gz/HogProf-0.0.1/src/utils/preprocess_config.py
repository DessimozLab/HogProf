
#turn the goDAG into a set of dictionaries
preprocessGO = True

string_interactors = '/scratch/cluster/monthly/dmoi/stringdata/protein.links.detailed.v10.5.txt'

preprocessSTRINGDB = False
uniprotmappings = '/scratch/cluster/monthly/dmoi/uniprotmapping/idmapping.dat'
startseq = 'Q7VBF3'

preprocessUNIPROT = False
#empty redis before storing string info
clearRedis= False
#use GO information in OMA
#use mapping info from uniprot

verbose = True
